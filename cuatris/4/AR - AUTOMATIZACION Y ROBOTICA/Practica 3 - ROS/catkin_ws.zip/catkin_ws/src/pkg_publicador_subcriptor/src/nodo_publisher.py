#!/usr/bin/env python
# license removed for brevity
import rospy
from std_msgs.msg import String

def talker():
    pub = rospy.Publisher('chatter', String, queue_size=10)
    rospy.init_node('talker', anonymous=True)
    rate = rospy.Rate(10) # 10hz
    contador=0
    while not rospy.is_shutdown():
        contador+=1
        hello_str = "Fran envio msg numero: " + str(contador)
        #hello_str = "Fran envia: " + str(msg)
        rospy.loginfo(str(hello_str))
        pub.publish(hello_str)
        rate.sleep()

if __name__ == '__main__':
    try:
        talker()
    except rospy.ROSInterruptException:
        pass