#! /usr/bin/env python
import rospy
rospy.init_node('SoyNodo')
print "Hola mi nombre es SoyNodo, encantado de conocerte"
