#include "Partido.h"

void Partido::anyadirVoto() { numvotos++; }
