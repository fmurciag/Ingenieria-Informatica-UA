
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <cstring>

using namespace std;

typedef struct {

 string nombre;
 int precio;
 int apariciones;
 
} Producto;


bool leerCatalogo(char *nf, vector<Producto> &vp)
{
  ifstream f;
  bool ok=false;
  
  f.open(nf);
  if (f.is_open())
  {
    ok=true;
    string line;
    
    while (getline(f,line))
    {
      stringstream ss;
      Producto p;
      
      ss << line;
      
      ss >> p.nombre >> p.precio;
      p.apariciones=0;
      
      vp.push_back(p);
    }
    
    f.close();
  }
  return ok;
}

void incrementaProd(string nom,vector<Producto> &vp)
{
  bool encontrado=false;

  for (unsigned int i=0;i<vp.size() && !encontrado;i++)
  {
    if (vp[i].nombre == nom)
    {
      encontrado=true;
      vp[i].apariciones++;
    }
  }
}

bool leerProductos(char *nf,vector<Producto> &vp)
{
  ifstream f;
  bool ok=false;
  
  f.open(nf);
  if (f.is_open())
  {
    ok=true;
    string nom;
    
    while (f >> nom)
    {
      incrementaProd(nom,vp);
    }
    
    f.close();
  }
  return ok;
}

void mostrarProductos(vector<Producto> &vp)
{
  int costeTotal=0,coste;;
  
  for (unsigned int i=0;i<vp.size();i++)
  {
    if (vp[i].apariciones>0)
    {
      coste = vp[i].precio*vp[i].apariciones;
      cout << vp[i].nombre << ": " << vp[i].apariciones << " x " << vp[i].precio << " = " << coste << endl;
      costeTotal += coste;
    }
  }
  cout << "------" << endl << "Coste: " << costeTotal << endl << "------" << endl;
}

const int MAXNOM=10;

typedef struct {

  char nombre[MAXNOM];
  int precio;
  int unidades;
  
} ProductoBin;

bool escribirBinario(vector<Producto> vp)
{
  bool ok=false;
  const char nfbin[]="compra.dat";
  ofstream f;
  
  f.open(nfbin,ios::out|ios::binary);
  if (f.is_open())
  {
    ok=true; // si se ha abierto, es que va a ir todo bien (suponemos)
    
    for (unsigned int i=0;i<vp.size();i++)
    if (vp[i].apariciones > 0)
    {
      ProductoBin pb;
      
      strncpy(pb.nombre,vp[i].nombre.c_str(),MAXNOM-1);
      pb.nombre[MAXNOM-1]='\0';
      pb.precio=vp[i].precio;
      pb.unidades=vp[i].apariciones;
      
      f.write((const char *)&pb,sizeof(pb));
    } 
    f.close();
  }
  else
    cout << "Error al abrir el fichero binario" << endl;
    
  return ok;
}


int main(int argc,char *argv[])
{
  if (argc == 3)
  {
     vector<Producto> vp;
  
     if (leerCatalogo(argv[2],vp))
     {
        if (leerProductos(argv[1],vp))
        {
          mostrarProductos(vp);
          escribirBinario(vp);
        }
        else
          cout << "Error al abrir el fichero de productos" << endl;
     }
     else
       cout << "Error al abrir el fichero del catálogo" << endl;
  }
  else
    cout << "Error, parámetros incorrectos: ./mantenimiento productos catalogo" << endl;
}
