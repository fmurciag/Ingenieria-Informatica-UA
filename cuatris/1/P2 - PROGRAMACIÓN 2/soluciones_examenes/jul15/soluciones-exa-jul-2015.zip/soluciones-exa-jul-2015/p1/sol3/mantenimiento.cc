#include <iostream>
#include <fstream>
#include <vector>
#include <cstring>

using namespace std;

const int kMAXNOM=10;

const char nombreFicheroSalida[]="compra.dat";

// Estructura para almacenar en memoria el nombre, precio y número de unidades de cada producto de la lista
typedef struct
{
  string nombre;
  int precio;
  int unidades;
}TProducto;

// Estructura para guardar en fichero el nombre, precio y número de unidades de cada producto de la lista
typedef struct
{
  char nombre[kMAXNOM];
  int precio;
  int unidades;
}TProductoBin;

int buscarProducto(string producto,const vector<TProducto> &listaProductos)
{
  bool encontrado=false;
  int indice=-1; // Si no encuentra el producto, devuelve "-1"
  
  for(int i=0;i<listaProductos.size() && !encontrado;i++)
  {
    if(producto==listaProductos[i].nombre)
    {
      encontrado==true;
      indice=i;
    }
  }
  
  return indice;
}

void leerProductos(ifstream &ficheroProductos,vector<TProducto> &listaProductos)
{
  string producto;
  
  // Lee hasta que encuentra un blanco y almacena en la variable "producto"
  while(ficheroProductos >> producto)
  {
    int indice=buscarProducto(producto,listaProductos);
    
    if(indice!=-1) // El producto ya existe en la lista
    {
      listaProductos[indice].unidades++;
    }
    else // El producto no existe en la lista
    {
      TProducto nuevo;
    
      nuevo.nombre=producto;
      nuevo.unidades=1;
      listaProductos.push_back(nuevo);
    }
  }
}

void leerCatalogo(ifstream &ficheroCatalogo,vector<TProducto> &listaProductos)
{
  string producto;
  int precio;

  // Lee hasta que encuentra un blanco y almacena en la variable "producto"  
  while(ficheroCatalogo >> producto)
  {
    // Lee el precio
    ficheroCatalogo >> precio;
    
    int indice=buscarProducto(producto,listaProductos);
    
    if(indice!=-1) // Si el producto está en la lista, almacenamos su precio
    {
      listaProductos[indice].precio=precio;
    }
  }  
}

void mostrarProductos(const vector<TProducto> &listaProductos)
{
  int total=0;
  
  for(int i=0;i<listaProductos.size();i++)
  {
    int parcial=listaProductos[i].unidades*listaProductos[i].precio; // El coste de un producto es el número de unidaes * precio
    cout << listaProductos[i].nombre << ": " << listaProductos[i].unidades << " x " << listaProductos[i].precio << " = " << parcial << endl;
    total+=parcial; // Vamos acumulando el coste del producto al total
  }
  
  cout << "------" << endl;
  cout << "Coste: " << total << endl;
  cout << "------" << endl;
}

void guardarProductos(const vector<TProducto> &listaProductos)
{
  ofstream ficheroSalida;
  
  ficheroSalida.open(nombreFicheroSalida,ios::out|ios::binary);
  if(ficheroSalida.is_open())
  {
    for(int i=0;i<listaProductos.size();i++)
    {
      TProductoBin nuevo;
      
      // Recortamos el nombre para que quepa en el vector de caracteres
      strncpy(nuevo.nombre,listaProductos[i].nombre.c_str(),kMAXNOM-1);
      nuevo.nombre[kMAXNOM-1]='\0';
      nuevo.precio=listaProductos[i].precio;
      nuevo.unidades=listaProductos[i].unidades;
      
      ficheroSalida.write((const char *)&nuevo,sizeof(TProductoBin));
    }
    
    ficheroSalida.close();
  }
  else
  {
    cout << "ERROR: no se ha podido crear el fichero \"" << nombreFicheroSalida << "\"" << endl;
  }
}

int main(int argc,char *argv[])
{
  vector<TProducto> listaProductos;
  string producto;
  
  if(argc==3) // Comprobamos que el número de parámetros de entrada sea correcto
  {
    ifstream ficheroProductos;
    ficheroProductos.open(argv[1],ios::in);
    if(ficheroProductos.is_open())
    {
      ifstream ficheroCatalogo(argv[2],ios::in);
      if(ficheroCatalogo.is_open())
      {
        // Leemos todos los productos del fichero y almacenamos en un vector cuántos hay de cada tipo
        leerProductos(ficheroProductos,listaProductos);
        
        // Guardamos el precio de cada producto
        leerCatalogo(ficheroCatalogo,listaProductos);
        
        // Mostramos por pantalla el coste total
        mostrarProductos(listaProductos);
        
        // Guardar productos en fichero binario
        guardarProductos(listaProductos);
      
        ficheroCatalogo.close();
      }
      else
      {
        cout << "ERROR: no se ha podido abrir el fichero \"" << argv[2] << "\"" << endl;
      }
      
      ficheroProductos.close();
    }
    else
    {
      cout << "ERROR: no se ha podido abrir el fichero \"" << argv[1] << "\"" << endl;
    }
  }
  else
  {
    cout << "USO: " << argv[0] << " <fichero productos> <fichero catalogo>" << endl;
  }
}
