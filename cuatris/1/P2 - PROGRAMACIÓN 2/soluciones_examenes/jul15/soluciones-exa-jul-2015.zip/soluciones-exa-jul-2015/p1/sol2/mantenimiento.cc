#include <iostream>
#include <fstream>
#include <vector>
#include <cstdlib>
#include <cstring>

using namespace std;


typedef struct
{
	string nombre;
	int precio;
	int unidades;
} Producto;

const int MAXNOM=10;

typedef struct
{
	char nombre[MAXNOM];
	int precio;
	int unidades;
} ProductoBin;


void leerProductos(ifstream &f, vector<Producto> &productos)
{
	string nombre;
	while( f >> nombre )
	{
		bool esta = false;
		for(unsigned i = 0; i < productos.size() && !esta; i++)
		{
			if(productos[i].nombre == nombre)
			{
				productos[i].unidades += 1;
				esta = true;
			}
		}
		if(!esta)
		{
			Producto producto;
			producto.nombre = nombre;
			producto.unidades = 1;
			productos.push_back(producto);
		}
	}
}

void escribirProductos(const vector<Producto> &productos)
{
	int costeTotal = 0;
	for(unsigned i = 0; i < productos.size(); i++)
	{
		int costeParcial = productos[i].unidades * productos[i].precio;
		costeTotal += costeParcial;
		cout << productos[i].nombre << ": " << productos[i].unidades
			<< " x " << productos[i].precio << " = " << costeParcial << endl;
	}
	cout << "------\nCoste: "<<  costeTotal << "\n------\n";
}


void procesarCatalogo(ifstream &f, vector<Producto> &productos)
{
	string nombre;
	int precio;
	while( f >> nombre)
	{
		f >> precio;
		for(unsigned i = 0; i < productos.size(); i++)
		{
			if( productos[i].nombre == nombre )
				productos[i].precio = precio;
		}
	} 
}


void escribirBinario(const vector<Producto> &productos)
{
	ofstream obf("compra.dat",ios::binary);
	if( obf.is_open() )
	{
		for(unsigned i = 0; i < productos.size(); i++)
		{
			ProductoBin prodBin;
			strncpy(prodBin.nombre,productos[i].nombre.c_str(),MAXNOM-1);
			prodBin.nombre[MAXNOM-1]='\0';
			prodBin.precio = productos[i].precio;
			prodBin.unidades = productos[i].unidades;
			obf.write((const char *)&prodBin,sizeof(prodBin));
		}
		obf.close();
	}
	else
		cout << "Error, no se pudo abrir el fichero \"compra.dat\" para escritura\n";
}


void comprobarBinario()
{
	ifstream ibf("compra.dat",ios::binary);
	if( ibf.is_open() )
	{
		ProductoBin prodBin;
		while(ibf.read((char *)&prodBin,sizeof(prodBin)))
		{
			cout << prodBin.nombre << ' ' << prodBin.precio << ' '
				<< prodBin.unidades << endl;
		}
		ibf.close();
	}
	else
		cout << "Error. No se puede abrir el fichero \"compra.dat\" para lectura\n";
}

int main(int argc,char *argv[])
{
	if(argc == 3)
	{
		bool correcto = true;
		ifstream fprod(argv[1]);
		ifstream fcatal(argv[2]);
		if(!fprod.is_open())
		{	
			cout << "Error, no se pudo abrir el fichero " << argv[1] << endl;
			correcto = false;
		}
		if(!fcatal.is_open())
		{	
			cout << "Error, no se pudo abrir el fichero " << argv[2] << endl;
			correcto = false;
		}
		if( correcto )
		{
			vector<Producto> productos;
			leerProductos(fprod,productos);
			fprod.close();
			procesarCatalogo(fcatal, productos);
			fcatal.close();
			escribirProductos(productos);
			escribirBinario(productos);
			//comprobarBinario();
		}
	}
	else
	{
		cout << "Error. Sintaxis: " << argv[0] << " productos catalogo\n";
	}
}
