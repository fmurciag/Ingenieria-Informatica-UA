#include "Route.h"


int Route::closest(const Planet &p) const
{
	int iclosest;
	if( planets.size() == 0)
		iclosest = -1;
	else
		iclosest = 0;
	for(unsigned i = 1; i < planets.size(); i++)
		if( planets[i].distance(p) < planets[iclosest].distance(p) )
			iclosest = i;
	return iclosest;
}

Route::Route(string name, const Planet &origin)
{
	this->name = name;
	planets.push_back(origin);
}

void Route::addPlanet(const Planet &p)
{
	int index = closest(p);
	planets.insert(planets.begin()+index+1,p);
}
	
ostream &operator<<(ostream &os, const Route &r)
{
	os << r.name << "\n----\n";
	for(unsigned i = 0; i < r.planets.size(); i++)
	{
		os << r.planets[i] << endl;
	}
	return os;
}
