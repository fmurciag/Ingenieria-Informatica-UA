#ifndef _PLANET_H_
#define _PLANET_H_

#include <iostream>

using namespace std;

class Planet
{
  private:
	string name;
	string sector;
	char letter;
	int number;
	
  public:
	Planet(string name = "Odik", string sector = "", string coord = "K11");
	float distance(const Planet &p) const;
	
  friend ostream &operator<<(ostream &os, const Planet &p);
};


#endif  //_PLANET_H_
