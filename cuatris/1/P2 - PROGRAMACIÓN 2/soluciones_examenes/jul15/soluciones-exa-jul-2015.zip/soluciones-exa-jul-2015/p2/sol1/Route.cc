
#include <iostream>

using namespace std;

#include "Route.h"

Route::Route(string name,const Planet &origin)
{
   this->name = name;
   planets.push_back(origin);
}

int Route::closest(const Planet &p) const
{
  int pos=-1;
  
  if (planets.size() > 0)  // debería ser siempre cierto
  {
    float dmin=p.distance(planets[0]);
    pos=0;
    
    for (unsigned int i=1;i<planets.size();i++)
    {
      float dp=p.distance(planets[i]);
      
      if (dp < dmin)
      {
        dmin=dp;
        pos=i;
      }
    }
  }
  return pos;
}

void Route::addPlanet(const Planet &p)
{
  int posClosest = closest(p);
 
  if (posClosest != -1)
  {
     // primera opción
     //planets.insert(planets.begin()+(posClosest+1),p);
     
     // segunda opción
     vector<Planet> nuevo;
     int i=0;
     
     // meter los planetas antes de closest (incluído, por eso es <=)
     while (i<=posClosest)
     {
       nuevo.push_back(planets[i]);
       i++;
     }
     nuevo.push_back(p); // meter el nuevo planeta después de closest
     
     // mater los planetas de después
     while (i<(int)planets.size())
     {
       nuevo.push_back(planets[i]);
       i++;
     }
     planets = nuevo;  // cambiar el vector entero
  }

}

ostream & operator << (ostream &os, const Route &r)
{
  os << r.name << endl;
  os << "------" << endl;
  for (unsigned int i=0;i<r.planets.size();i++)
    os << r.planets[i];
  
  return os;
}
