
#include <iostream>
#include <cstdlib>
#include <cmath>

using namespace std;

#include "Planet.h"

Planet::Planet(string name,string sector,string coord)
{
  this->name = name;
  this->sector = sector;
  this->letter = coord[0];
  
  string num="";
  for (unsigned int i=1;i<coord.length();i++)
    num += coord[i];
    
  this->number = atoi(num.c_str());
}

float Planet::distance(const Planet &p) const
{
  float dist;
  
  dist = 100 * abs(letter-p.letter) + abs(number - p.number);
  
  return dist;
}

ostream & operator << (ostream &os, const Planet &p)
{
  os << p.name << " (" << p.sector << "), " << p.letter << p.number << endl;
  
  return os;
}
