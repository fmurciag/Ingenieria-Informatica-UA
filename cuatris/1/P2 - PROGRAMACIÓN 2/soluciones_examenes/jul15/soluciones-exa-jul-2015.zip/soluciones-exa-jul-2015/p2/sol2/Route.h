#ifndef _ROUTE_H_
#define _ROUTE_H_

#include <iostream>
#include <vector>

#include "Planet.h"

using namespace std;

class Route
{
  private:
	string name;
	vector<Planet> planets;
	int closest(const Planet &p) const;
	
  public:
	Route(string name, const Planet &origin);
	void addPlanet(const Planet &p);
	string getName() { return name; }
	void setName(string name) { this->name = name; }
	
  friend ostream &operator<<(ostream &os, const Route &r);
};


#endif  //_ROUTE_H_
