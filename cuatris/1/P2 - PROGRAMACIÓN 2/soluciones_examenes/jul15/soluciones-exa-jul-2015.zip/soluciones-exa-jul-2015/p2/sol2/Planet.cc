#include <iostream>
#include <cstdlib>

#include "Planet.h"

using namespace std;

Planet::Planet(string name, string sector, string coord)
{
	this->name = name;
	this->sector = sector;
	letter = coord[0];
	// también se podría hacer con string::substr()
	string aux;
	for(unsigned i = 1; i < coord.length(); i++)
		aux+=coord[i];
	number = atoi(aux.c_str());
}
	

float Planet::distance(const Planet &p) const
{
	return 100*abs(letter-p.letter) + abs(number-p.number);
}
	
	
	
ostream &operator<<(ostream &os, const Planet &p)
{
	os << p.name << " (" << p.sector << "), " << p.letter << p.number;
	return os;
}
