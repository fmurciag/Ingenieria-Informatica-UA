
#ifndef _Route_
#define _Route_

#include <vector>
#include <iostream>

using namespace std;

#include "Planet.h"

class Route {

  private:
   
     string name;
     vector<Planet> planets;
     
  public:
  
     Route(string name,const Planet &origin);
     int closest(const Planet &p) const;
     void addPlanet(const Planet &p);
     string getName() const { return name; };
     void setName(string name) { this->name=name;};
     
     friend ostream & operator << (ostream &os,const Route &r);
};

#endif
