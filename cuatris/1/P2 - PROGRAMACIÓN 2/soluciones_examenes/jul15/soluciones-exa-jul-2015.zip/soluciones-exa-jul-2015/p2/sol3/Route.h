#ifndef _ROUTE_
#define _ROUTE_

#include <iostream>
#include <vector>
#include "Planet.h"

using namespace std;

class Route
{
  friend ostream& operator<<(ostream &os,const Route &r);
  private:
    string name;
    vector<Planet> planets; // Vector para almacenar los planetas de la ruta
    int closest(const Planet &p) const;
  public:
    Route(string name,const Planet &origin);
    void addPlanet(const Planet &p);
    string getName() const;
    void setName(string name);
};

#endif
