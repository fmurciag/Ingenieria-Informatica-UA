#include "Route.h"

int main()
{
  Route r("My route", Planet("Endor","Zuma","H16"));
  
  r.addPlanet(Planet("Felucia","Thanium","R6"));
  r.addPlanet(Planet("Geonosis","Arkanis","R16"));
  r.addPlanet(Planet("Ansion","Churnis","I6"));
  r.addPlanet(Planet("Phoebus","Thanium","R6"));
  r.addPlanet(Planet("Subterrel","Subterrel","L20"));

  cout <<  r << endl;
}
