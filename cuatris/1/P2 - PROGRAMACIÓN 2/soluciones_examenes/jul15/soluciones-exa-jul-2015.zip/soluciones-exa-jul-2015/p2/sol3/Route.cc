#include "Route.h"

Route::Route(string name,const Planet &origin)
{
  this->name=name;
  planets.push_back(origin);
}

int Route::closest(const Planet &p) const
{
  int indice=-1; // Si el vector de planetas está vacío, devuelve "-1"
  int distanciaMenor=0;
  
  for(int i=0;i<planets.size();i++)
  {
    int distancia=p.distance(planets[i]);
    if(distancia<distanciaMenor || indice==-1) // Si la distancia es menor, o es la primera vez que comparamos
    {
      indice=i;
      distanciaMenor=distancia;
    }
  }
  
  return indice;
}

void Route::addPlanet(const Planet &p)
{
  // Tanto si no hay planetas, como si hay uno sólo, la acción consistirá en añadir el nuevo al final
  if(planets.size()<2)
  {
    planets.push_back(p);
  }
  else
  {
    int indice=closest(p); // Identificamos el planeta más cercano. Deberemos insertar detrás de éste

    // Hacemos hueco en el vector desplazando a la derecha
    planets.resize(planets.size()+1); // Incrementamos el tamaño del vector para que quepa el nuevo
    for(int i=planets.size()-1;i>indice+1;i--) // Desde la última posición y mientras que no lleguemos al índice del planeta más cercano
    {
      planets[i]=planets[i-1]; // Vamos desplazando los planetas hacia el final del vector
    }
    
    planets[indice+1]=p; // Insertamos el nuevo planeta detrás del más cercano (situado en "indice")
  }
}

string Route::getName() const
{
  return name;
}

void Route::setName(string name)
{
  this->name=name;
}

ostream& operator<<(ostream &os,const Route &r)
{
  os << r.name << endl;
  os << "----" << endl;
  for(int i=0;i<r.planets.size();i++)
  {
    os << r.planets[i] << endl;
  }
  
  return os;
}
