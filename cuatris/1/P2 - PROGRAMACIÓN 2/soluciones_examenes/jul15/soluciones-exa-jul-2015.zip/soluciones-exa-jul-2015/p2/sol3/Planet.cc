#include <stdlib.h> // Para abs()
#include "Planet.h"

Planet::Planet(string name,string sector,string coord)
{
  this->name=name;
  this->sector=sector;
  letter=coord[0]; // Extraemos la letra de la coordenada
  number=atoi(coord.substr(1).c_str()); // Extraemos el número de la coordenada
}

float Planet::distance(const Planet &p) const
{
  float distancia=100*abs(letter-p.letter)+abs(number-p.number);
  
  return distancia;
}

ostream& operator<<(ostream &os,const Planet &p)
{
  os << p.name << " (" << p.sector << "), " << p.letter << p.number;

  return os;
}
