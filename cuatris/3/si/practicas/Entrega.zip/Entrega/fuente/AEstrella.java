/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AEstrella;
import static java.lang.Math.abs;
import java.util.ArrayList;

/**
 *
 * @author Francisco Murcia Gomez
 */
public class AEstrella {
 
    //Mundo sobre el que se debe calcular A*
    Mundo mundo;
    
    //Camino
    public char camino[][];
    
    //Casillas expandidas
    int camino_expandido[][];
    
    //Número de nodos expandidos
    int expandidos;
    
    //Coste del camino
    float coste_total;
    private ArrayList<Estado> estados;
    
    public AEstrella(){
        expandidos = 0;
        mundo = new Mundo();
    }
    
    
    public AEstrella(Mundo m){
        //Copia el mundo que le llega por parámetro
        mundo = new Mundo(m);
        camino = new char[m.tamanyo_y][m.tamanyo_x];
        camino_expandido = new int[m.tamanyo_y][m.tamanyo_x];
        expandidos = 0;
        
        //Inicializa las variables camino y camino_expandidos donde el A* debe incluir el resultado
            for(int i=0;i<m.tamanyo_x;i++)
                for(int j=0;j<m.tamanyo_y;j++){
                    camino[j][i] = '.';
                    camino_expandido[j][i] = -1;
                }
    }
    
    
    
    private ArrayList<Estado> hijos(Estado n){///selecionamos los adyacentes
        ArrayList<Estado>Hijos=new ArrayList<>();
        int X= n.getN().getX();
        int Y=n.getN().getY();
        
        if(Y%2==0){//fila par      
            for (int i = -1; i <=1; i++) {//X
                for (int j = -1; j <= 1; j++) {//Y
                    if((i==-1&&j==0)||(i==0&&j==-1)||(i==1&&j==-1)||(i==1&&j==0)||(i==1&&j==1)||(i==0&&j==1)){// cooredenadas validas par 
                            
                        Estado a=new Estado(0, 0,null ,null);
                        int h=0;
                        switch(mundo.getCelda(X+i, Y+j)){
                            
                            case 'a':
                                a.setN(new Coordenada(X+i,Y+j));
                                h=heuristica(a.getN());
                                a.setH(h);
                                a.setCosteCelda(3);
                                Hijos.add(a);
                                break;
                            case 'h':
                                a.setN(new Coordenada(X+i,Y+j));
                                h=heuristica(a.getN());
                                a.setH(h);
                                a.setCosteCelda(2);
                                Hijos.add(a);
                                break;
                            case 'c':
                                a.setN(new Coordenada(X+i,Y+j));
                                h=heuristica(a.getN());
                                a.setH(h);
                                a.setCosteCelda(1);
                                Hijos.add(a);
                                break;
                            case 'd':
                                a.setN(new Coordenada(X+i,Y+j));
                                h=heuristica(a.getN());
                                a.setH(h);
                                a.setCosteCelda(1);
                                Hijos.add(a);
                                break;
                        }
                    }
                }
            }
        }else{//fila impar
                
            for (int i = -1; i <=1; i++) {//X
                for (int j = -1; j <= 1; j++) {//Y
                    if((i==1&&j==0)||(i==0&&j==-1)||(i==-1&&j==-1)||(i==-1&&j==0)||(i==-1&&j==1)||(i==0&&j==1)){//cooredenadas validas impar 

                        Estado a=new Estado(0, 0,null ,null);
                        int h=0;
                        switch(mundo.getCelda(X+i, Y+j)){
                            
                            case 'a':
                                a.setN(new Coordenada(X+i,Y+j));
                                h=heuristica(a.getN());
                                a.setH(h);
                                a.setCosteCelda(3);
                                Hijos.add(a);
                                
                                break;
                            case 'h':
                                a.setN(new Coordenada(X+i,Y+j));
                                h=heuristica(a.getN());
                                a.setH(h);
                                a.setCosteCelda(2);
                                Hijos.add(a);
                                break;
                            case 'c':
                                a.setN(new Coordenada(X+i,Y+j));
                                h=heuristica(a.getN());
                                a.setH(h);
                                a.setCosteCelda(1);
                                Hijos.add(a);
                                break;
                            case 'd':
                                a.setN(new Coordenada(X+i,Y+j));
                                h=heuristica(a.getN());
                                a.setH(h);
                                a.setCosteCelda(1);
                                Hijos.add(a);
                                break;
                        }
                    }
                }
            }
        }
       
        return Hijos;
            
        
    }
    
    private boolean estaEnLista(Estado hijo ,ArrayList<Estado>listaInterior){//miramos si un estado esta en una lista
        
        for(Estado e:listaInterior){
            if((e.getN().getX()==hijo.getN().getX())&&(e.getN().getY()==hijo.getN().getY())){
                
                return true;
            }
        }       
        return false;   
    }
    
    
    
    private Cubo axialToCubica(Coordenada a){
        
        int x=a.getX()-(a.getY()+(a.getY()&1))/2;
        int z=a.getY();
        int y=-x-z;
        Cubo c=new  Cubo(x,y,z);
        return c;
    }
    public int distanciaCuboToCubo(Cubo a, Cubo b){
        return (abs(a.getX() - b.getX()) + abs(a.getY() - b.getY()) + abs(a.getZ() - b.getZ())) / 2;
    }
    
    
    private int heuristica(Coordenada a){
        
        /*
        Con la siguiente variable se puede cambiar de heurstica
        simplemente hay que cambiar el numero de la variable "tipoDeHeuristica"
        */
        int tipoDeHeuristica=3;
        /*
        DISTANCIAS:
        Manhattan --> 1
        Eucl�dea ---> 2
        Cubica -----> 3
        En el caso de no selecionar ninguno de estos valores, no se empleara ninguna heuristica
        */

        int h=0;
        switch (tipoDeHeuristica){
            case 1://distancia manhattan
                h=abs(mundo.dragon.getX()-a.getX())+abs(mundo.dragon.getY()-a.getY());
                break;
            case 2://distancia Eucl�dea
                int X=mundo.dragon.getX()-a.getX();
                int Y=mundo.dragon.getY()-a.getY();
                h=(int) Math.sqrt(X*X+Y*Y);
                break;
            case 3://distancia cubica
                Cubo c= new Cubo();
                h= distanciaCuboToCubo(axialToCubica(mundo.dragon),axialToCubica(a));
                break;
        }
        return h;
        
    }
    
    
    //Calcula el A*
    public int CalcularAEstrella(){

        
        
        
        
        //System.out.println("X="+mundo.caballero.getX()+" Y="+mundo.caballero.getY());
        //System.out.println("X="+mundo.dragon.getX()+" Y="+mundo.dragon.getY());
        boolean encontrado = false;
        int result = -1;
        
        
        
        
        ArrayList<Estado>listaInterior=new ArrayList<>();
        ArrayList<Estado>listaFrontera=new ArrayList<>();
        Estado padre=new Estado(0,heuristica(mundo.getCaballero()) ,mundo.getCaballero(),null);
        listaFrontera.add(padre);
        
        
        
        while(!listaFrontera.isEmpty()&& encontrado==false){
            Estado n=listaFrontera.get(0);
            
           
            
            for(Estado e:listaFrontera){// obtener nodo de listaFrontera con menor f(n) = g(n) + h(n) 
                //System.out.println("{X="+e.getN().getX()+" Y="+e.getN().getY()+"| F="+e.getF()+" G="+e.getG()+" H="+e.getH()+"}");
                if(n.getF()>e.getF())n=e;
            }
            //System.out.println();
            camino_expandido[n.getN().getY()][n.getN().getX()] = expandidos;
            expandidos++;
           
             
             
            
            if(n.getN().getX()==mundo.getDragon().getX() && n.getN().getY()==mundo.getDragon().getY()){//si n es meta
                encontrado=true;
                coste_total=n.getG();
                result=(int) coste_total;
                
                while (n!=null){//reconstruir camino desde la meta al inicio siguiendo los punteros 
                    camino[n.getN().getY()][n.getN().getX()]='X';
                    n=n.getPadre();
                }
                
            }else{
                
                
               
                
                listaFrontera.remove(n);
                listaInterior.add(n);
                
                
                
                ArrayList<Estado>Hijos=hijos(n);//a�adimos los adyacentes a un alista auxiliar
                
               /*for (Estado hijo:Hijos){
                   System.out.println("{X="+hijo.getN().getX()+" Y="+hijo.getN().getY()+"| F="+hijo.getF()+" G="+hijo.getG()+" H="+hijo.getH()+"}");
               }
                System.out.println();
                System.out.println();*/
                for(Estado hijo:Hijos){//para cada hijo
                    
                   if(!estaEnLista(hijo,listaInterior)){
                       
                       int costeHijo=hijo.getCosteCelda()+n.getG();
                       int H=hijo.getH();
                       if(!estaEnLista(hijo,listaFrontera)){//si el hijo no esta en lista frontera
                           
                           hijo.setG(costeHijo);
                           hijo.setH(H);
                           hijo.setPadre(n);
                           listaFrontera.add(hijo);
                       }else if(hijo.getG()>costeHijo){//si es mejor opcion
                           
                           listaFrontera.remove(hijo);
                           hijo.setPadre(n);
                           hijo.setG(costeHijo);
                           hijo.setH(H);
                           listaFrontera.add(hijo);
                       }  
                   }
                }
            }  
        }
        
        
        
        
        //AQU�? ES DONDE SE DEBE IMPLEMENTAR A*
       

        //Si ha encontrado la solución, es decir, el camino, muestra las matrices camino y camino_expandidos y el número de nodos expandidos
        if(encontrado){
            //Mostrar las soluciones
            System.out.println("Camino");
            mostrarCamino();

            System.out.println("Camino explorado");
            mostrarCaminoExpandido();
            
            System.out.println("Nodos expandidos: "+expandidos);
        }

        return result;
    }
    

    
    
   
    
    //Muestra la matriz que contendrá el camino después de calcular A*
    public void mostrarCamino(){
        for (int i=0; i<mundo.tamanyo_y; i++){
            if(i%2==0)
                System.out.print(" ");
            for(int j=0;j<mundo.tamanyo_x; j++){
                System.out.print(camino[i][j]+" ");
            }
            System.out.println();   
        }
    }
    
    //Muestra la matriz que contendrá el orden de los nodos expandidos después de calcular A*
    public void mostrarCaminoExpandido(){
        for (int i=0; i<mundo.tamanyo_y; i++){
            if(i%2==0)
                    System.out.print(" ");
            for(int j=0;j<mundo.tamanyo_x; j++){
                if(camino_expandido[i][j]>-1 && camino_expandido[i][j]<10)
                    System.out.print(" ");
                System.out.print(camino_expandido[i][j]+" ");
            }
            System.out.println();   
        }
    }
    
    public void reiniciarAEstrella(Mundo m){
        //Copia el mundo que le llega por parámetro
        mundo = new Mundo(m);
        camino = new char[m.tamanyo_y][m.tamanyo_x];
        camino_expandido = new int[m.tamanyo_y][m.tamanyo_x];
        expandidos = 0;
        
        //Inicializa las variables camino y camino_expandidos donde el A* debe incluir el resultado
            for(int i=0;i<m.tamanyo_x;i++)
                for(int j=0;j<m.tamanyo_y;j++){
                    camino[j][i] = '.';
                    camino_expandido[j][i] = -1;
                }
    }
    
    public float getCosteTotal(){
        return coste_total;
    }
    
    
  
    
    
    
    
}







