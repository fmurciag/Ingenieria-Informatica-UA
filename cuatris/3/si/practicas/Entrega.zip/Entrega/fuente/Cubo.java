/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AEstrella;

import static java.lang.Math.abs;

/**
 *
 * @author Francisco Murcia Gomez
 */
public class Cubo {
    
    private int x;
    private int y;
    private int z;
   
  
    public Cubo(){
        x=0;
        y=0;
        z=0;
    }
    
    public Cubo(int X,int Y, int Z){
        x=X;
        y=Y;
        z=Z;
    }
    
    
     public int getX(){
        return x;
    }   
    public int getY(){
        return y;
    }
     public int getZ(){
        return z;
    }
    
    
    
    
    
    
}
