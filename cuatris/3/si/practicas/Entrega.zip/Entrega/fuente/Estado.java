/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AEstrella;


import java.util.Objects;

/**
 *
 * clase para tener los costes, la coordenada y padre
 * 
 * @author Francisco Murcia Gomez
 */
public class Estado {
    private int F;//coste de la funcion
    private int G;//coste del camino
    private int H;//heuristica
    private Coordenada N;//coordenada
    private Estado Padre;
    private int costeCelda;

    public Estado(int costeCelda, int H, Coordenada N, Estado Padre) {
        this.G=0;
        this.H = H;//la heuristica
        this.N = N;//corrodenada
        this.Padre = Padre;
        this.costeCelda=costeCelda;
        this.F = G+H;//coste de la funcion
    }

    
     
    @Override
    public int hashCode() {
        int hash = 3;
        hash = 29 * hash + this.F;
        hash = 29 * hash + this.G;
        hash = 29 * hash + this.H;
        hash = 29 * hash + Objects.hashCode(this.N);
        hash = 29 * hash + Objects.hashCode(this.Padre);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Estado other = (Estado) obj;
        if (this.F != other.F) {
            return false;
        }
        if (this.G != other.G) {
            return false;
        }
        if (this.H != other.H) {
            return false;
        }
        if (!Objects.equals(this.N, other.N)) {
            return false;
        }
        return Objects.equals(this.Padre, other.Padre);
    }
    

    public int getF() {
        return F;
    }

    public int getG() {
        return G;
    }

    public int getH() {
        return H;
    }

    public Coordenada getN() {
        return N;
    }

    public Estado getPadre() {
        return Padre;
    }
    
    public int getCosteCelda() {
        return costeCelda;
    }

    public void setF(int F) {
        this.F = F;
    }

    public void setG(int G) {
        this.G = G;
        this.F=G+H;//cuando actualizamos el coste total la funcion se actualiza
        
    }

    public void setH(int H) {
        this.H = H;
        this.F=G+H;//cuando actualizamos la h  la funcion se actualiza
    }

    public void setN(Coordenada N) {
        this.N = N;
    }

    public void setPadre(Estado Padre) {
        this.Padre = Padre;
    }
    
    public void setCosteCelda(int N) {
        this.costeCelda = N;
    }
    
     @Override
    public String toString() {
        return "Estado{" + "F=" + F + ", G=" + G + ", H=" + H + ", N=" + N + ", Padre=" + Padre + '}';
    }
    
    
}
