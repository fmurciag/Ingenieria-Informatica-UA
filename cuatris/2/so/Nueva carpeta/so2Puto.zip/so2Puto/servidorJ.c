#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <arpa/inet.h>


#define PUERTO 9999

int tam_buffer = 999999;

int main(int argc, char *argv[]){
  int sfd, nsfd, pid;
  int cli_addr_len;
  struct sockaddr_in servidor, cli_addr; 
  char buffer[tam_buffer];
  char linea[8192];
  
  FILE *archivo;
  // Aprtura de un conector orientado a conexión, de la familia AF_INET
  if ((sfd = socket(AF_INET, SOCK_STREAM , 0))==-1){
    printf("Error, no se ha podido abrir el socket\n");
    exit(-1);
  }

  servidor.sin_family =  AF_INET; 
  servidor.sin_addr.s_addr = INADDR_ANY; 
  servidor.sin_port = htons(PUERTO);

  if (bind(sfd , (struct sockaddr*) &servidor, sizeof(servidor)) == -1){
    printf("Error de bind\n");
    exit(-1);
  } 
  // queremos que haya hasta 5 peticiones atendidas simultáneas
  listen(sfd,5); 
  // Bucle de lectura de peticiones de conexión
  for (;;){
	  printf("***************************\nEsperando conexion...\n");
    cli_addr_len = sizeof(cli_addr);
    if ((nsfd=accept(sfd, (struct sockaddr*)&cli_addr,&cli_addr_len))==-1){ //Como en cliente, rellenar con struct
      printf("Error de accept\n");
      exit(-1); 
    }
    else{
      archivo = fopen("Google.html","r");

      if(archivo == NULL){
        perror("Error al abrir el fichero");
         return -1;
      }
      while( fgets(linea,10000, archivo) != NULL){
        strcat(buffer,linea);
      }
	  printf("Enviando...\n\n");
      //printf("%s",buffer);
	  send(nsfd,buffer,sizeof(buffer),0);
      fclose(archivo);
    } 
    // Se crea un proceso hijo (fork) para atender al cliente  
    if ((pid=fork()==0)){ // Código del hijo
      close(sfd);  // Se cierra el descriptor de escucha
      // Acciones sobre el descriptor nsfd
      close(nsfd); // Se cierra el descriptor de conexión
      exit(0);
    }
    // Código del padre
    close(nsfd);   // Se cierra el descriptor de conexión
   }
}