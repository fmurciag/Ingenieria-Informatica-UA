package model.exceptions.score;

public class EmptyRankingException extends Exception {

	

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public EmptyRankingException() {
		super("EmptyRankingException");
		// TODO Auto-generated constructor stub
	}


}
