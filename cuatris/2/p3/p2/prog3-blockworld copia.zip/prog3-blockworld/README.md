### Proyecto Eclipse base para las prácticas de 'Programación 3', curso 2019-2020
